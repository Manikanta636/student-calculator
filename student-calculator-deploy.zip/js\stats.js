/**
 * OmniCalc - Statistics Engine
 * Computes descriptive statistics for arbitrary numerical datasets
 */

const StatsEngine = {
  parseInput(rawText) {
    if (!rawText) return [];
    // Split by commas, spaces, newlines, semicolons
    const tokens = rawText.split(/[\s,;\n]+/);
    const nums = tokens
      .map(t => parseFloat(t))
      .filter(n => !isNaN(n) && isFinite(n));
    return nums;
  },

  analyze(nums) {
    if (!nums || nums.length === 0) {
      return null;
    }

    const n = nums.length;
    const sorted = [...nums].sort((a, b) => a - b);
    
    // Sum
    const sum = sorted.reduce((acc, val) => acc + val, 0);
    
    // Mean
    const mean = sum / n;

    // Median
    let median = 0;
    if (n % 2 === 1) {
      median = sorted[Math.floor(n / 2)];
    } else {
      const mid = n / 2;
      median = (sorted[mid - 1] + sorted[mid]) / 2;
    }

    // Mode
    const freqMap = {};
    let maxFreq = 0;
    sorted.forEach(val => {
      freqMap[val] = (freqMap[val] || 0) + 1;
      if (freqMap[val] > maxFreq) maxFreq = freqMap[val];
    });

    let modes = [];
    if (maxFreq > 1) {
      modes = Object.keys(freqMap)
        .filter(k => freqMap[k] === maxFreq)
        .map(Number);
    }

    // Min / Max / Range
    const min = sorted[0];
    const max = sorted[n - 1];
    const range = max - min;

    // Variance & Standard Deviation
    const popVariance = sorted.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / n;
    const popStdDev = Math.sqrt(popVariance);

    const sampleVariance = n > 1 ? sorted.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / (n - 1) : 0;
    const sampleStdDev = Math.sqrt(sampleVariance);

    // Quartiles Q1 and Q3
    const getPercentile = (arr, p) => {
      const index = (arr.length - 1) * p;
      const lower = Math.floor(index);
      const upper = Math.ceil(index);
      const weight = index - lower;
      return arr[lower] * (1 - weight) + arr[upper] * weight;
    };

    const q1 = getPercentile(sorted, 0.25);
    const q3 = getPercentile(sorted, 0.75);

    return {
      count: n,
      sum: sum,
      mean: mean,
      median: median,
      mode: modes.length > 0 ? modes.join(', ') : 'None',
      min: min,
      max: max,
      range: range,
      popVariance: popVariance,
      popStdDev: popStdDev,
      sampleVariance: sampleVariance,
      sampleStdDev: sampleStdDev,
      q1: q1,
      q3: q3,
      sorted: sorted
    };
  }
};
