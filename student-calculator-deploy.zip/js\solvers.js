/**
 * OmniCalc - Solvers & Geometry Engine
 * Quadratic solver, 2x2 linear system solver, and geometry properties solver
 */

const SolversEngine = {
  // Quadratic equation ax^2 + bx + c = 0
  solveQuadratic(a, b, c) {
    if (a === 0) {
      if (b === 0) {
        return {
          roots: c === 0 ? "Infinite solutions" : "No solution",
          steps: "Invalid equation: 0 = 0 or c ≠ 0"
        };
      }
      const x = -c / b;
      return {
        roots: `Linear Equation: x = ${x.toFixed(4)}`,
        steps: `Since a = 0, equation reduced to linear ${b}x + ${c} = 0 → x = ${x.toFixed(4)}`
      };
    }

    const delta = b * b - 4 * a * c;
    const absA = Math.abs(a);

    if (delta > 0) {
      const sqrtDelta = Math.sqrt(delta);
      const x1 = (-b + sqrtDelta) / (2 * a);
      const x2 = (-b - sqrtDelta) / (2 * a);
      return {
        roots: `x₁ = ${x1.toFixed(4)},  x₂ = ${x2.toFixed(4)}`,
        steps: `Discriminant Δ = b² - 4ac = (${b})² - 4(${a})(${c}) = ${delta.toFixed(4)} > 0 (Two Real & Distinct Roots)`
      };
    } else if (delta === 0) {
      const x = -b / (2 * a);
      return {
        roots: `x₁ = x₂ = ${x.toFixed(4)}`,
        steps: `Discriminant Δ = b² - 4ac = (${b})² - 4(${a})(${c}) = 0 (One Double Real Root)`
      };
    } else {
      const realPart = (-b / (2 * a)).toFixed(4);
      const imagPart = (Math.sqrt(-delta) / (2 * absA)).toFixed(4);
      return {
        roots: `x₁ = ${realPart} + ${imagPart}i,  x₂ = ${realPart} - ${imagPart}i`,
        steps: `Discriminant Δ = b² - 4ac = ${delta.toFixed(4)} < 0 (Complex Conjugate Roots)`
      };
    }
  },

  // 2x2 System of linear equations:
  // a1*x + b1*y = c1
  // a2*x + b2*y = c2
  solveLinear2x2(a1, b1, c1, a2, b2, c2) {
    const det = a1 * b2 - a2 * b1;
    if (Math.abs(det) < 1e-12) {
      const detC1 = c1 * b2 - c2 * b1;
      if (Math.abs(detC1) < 1e-12) {
        return { roots: "Dependent Lines (Infinitely Many Solutions)" };
      } else {
        return { roots: "Parallel Lines (No Solution)" };
      }
    }

    const x = (c1 * b2 - c2 * b1) / det;
    const y = (a1 * c2 - a2 * c1) / det;

    return {
      roots: `x = ${x.toFixed(4)},  y = ${y.toFixed(4)}`
    };
  },

  // Geometry Property Calculator
  solveGeometry(shape, params) {
    if (shape === 'circle') {
      const r = parseFloat(params.radius) || 0;
      const area = Math.PI * r * r;
      const circ = 2 * Math.PI * r;
      return `Radius = ${r}\nArea = ${area.toFixed(4)}\nCircumference = ${circ.toFixed(4)}`;
    } else if (shape === 'triangle') {
      const a = parseFloat(params.base) || 0;
      const b = parseFloat(params.height) || 0;
      const c = Math.sqrt(a * a + b * b);
      const area = 0.5 * a * b;
      const perim = a + b + c;
      return `Hypotenuse c = ${c.toFixed(4)}\nArea = ${area.toFixed(4)}\nPerimeter = ${perim.toFixed(4)}`;
    } else if (shape === 'sphere') {
      const r = parseFloat(params.radius) || 0;
      const vol = (4 / 3) * Math.PI * Math.pow(r, 3);
      const sa = 4 * Math.PI * r * r;
      return `Radius = ${r}\nVolume = ${vol.toFixed(4)}\nSurface Area = ${sa.toFixed(4)}`;
    } else if (shape === 'cylinder') {
      const r = parseFloat(params.radius) || 0;
      const h = parseFloat(params.height) || 0;
      const vol = Math.PI * r * r * h;
      const sa = 2 * Math.PI * r * (r + h);
      return `Radius = ${r}, Height = ${h}\nVolume = ${vol.toFixed(4)}\nTotal Surface Area = ${sa.toFixed(4)}`;
    }
    return 'Invalid selection';
  }
};
