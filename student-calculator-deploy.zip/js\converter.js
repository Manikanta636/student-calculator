/**
 * OmniCalc - Multi-Unit Converter Engine
 */

const ConverterEngine = {
  units: {
    length: {
      base: 'm',
      rates: {
        'm': 1,
        'km': 1000,
        'cm': 0.01,
        'mm': 0.001,
        'mile': 1609.344,
        'yard': 0.9144,
        'foot': 0.3048,
        'inch': 0.0254
      },
      labels: {
        'm': 'Meter (m)',
        'km': 'Kilometer (km)',
        'cm': 'Centimeter (cm)',
        'mm': 'Millimeter (mm)',
        'mile': 'Mile (mi)',
        'yard': 'Yard (yd)',
        'foot': 'Feet (ft)',
        'inch': 'Inch (in)'
      }
    },
    mass: {
      base: 'kg',
      rates: {
        'kg': 1,
        'g': 0.001,
        'mg': 0.000001,
        'lb': 0.45359237,
        'oz': 0.028349523125,
        'ton': 1000
      },
      labels: {
        'kg': 'Kilogram (kg)',
        'g': 'Gram (g)',
        'mg': 'Milligram (mg)',
        'lb': 'Pound (lb)',
        'oz': 'Ounce (oz)',
        'ton': 'Metric Ton (t)'
      }
    },
    temperature: {
      special: true,
      labels: {
        'c': 'Celsius (°C)',
        'f': 'Fahrenheit (°F)',
        'k': 'Kelvin (K)'
      }
    },
    area: {
      base: 'm2',
      rates: {
        'm2': 1,
        'km2': 1000000,
        'ft2': 0.092903,
        'acre': 4046.86,
        'hectare': 10000
      },
      labels: {
        'm2': 'Square Meter (m²)',
        'km2': 'Square Kilometer (km²)',
        'ft2': 'Square Feet (ft²)',
        'acre': 'Acre',
        'hectare': 'Hectare'
      }
    },
    volume: {
      base: 'l',
      rates: {
        'l': 1,
        'ml': 0.001,
        'm3': 1000,
        'gal': 3.78541,
        'cup': 0.236588
      },
      labels: {
        'l': 'Liter (L)',
        'ml': 'Milliliter (mL)',
        'm3': 'Cubic Meter (m³)',
        'gal': 'US Gallon (gal)',
        'cup': 'US Cup'
      }
    },
    speed: {
      base: 'ms',
      rates: {
        'ms': 1,
        'kmh': 0.277778,
        'mph': 0.44704,
        'knot': 0.514444
      },
      labels: {
        'ms': 'Meters / sec (m/s)',
        'kmh': 'Km / hour (km/h)',
        'mph': 'Miles / hour (mph)',
        'knot': 'Knot (kt)'
      }
    }
  },

  convert(cat, val, fromUnit, toUnit) {
    if (isNaN(val)) return 0;
    
    if (cat === 'temperature') {
      let celsius = val;
      if (fromUnit === 'f') celsius = (val - 32) * (5 / 9);
      if (fromUnit === 'k') celsius = val - 273.15;

      if (toUnit === 'c') return celsius;
      if (toUnit === 'f') return celsius * (9 / 5) + 32;
      if (toUnit === 'k') return celsius + 273.15;
    }

    const catData = this.units[cat];
    if (!catData || !catData.rates) return val;

    const baseVal = val * catData.rates[fromUnit];
    const targetVal = baseVal / catData.rates[toUnit];
    return targetVal;
  }
};
