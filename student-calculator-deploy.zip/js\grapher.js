/**
 * OmniCalc - 2D Interactive Function Grapher Engine
 * Canvas-based plotting with grid rendering, coordinate tracing, pan & zoom
 */

class Grapher {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext('2d');
    
    // View bounds
    this.xMin = -10;
    this.xMax = 10;
    this.yMin = -10;
    this.yMax = 10;

    // Functions to plot
    this.func1Str = "x^2 - 4";
    this.color1 = "#00f2fe";
    
    this.func2Str = "sin(x)";
    this.color2 = "#ff4b8b";

    // Mouse pan/zoom state
    this.isDragging = false;
    this.dragStartX = 0;
    this.dragStartY = 0;
    this.traceX = 0;
    this.traceY1 = null;
    this.traceY2 = null;

    this.initEvents();
    this.resizeCanvas();
  }

  resizeCanvas() {
    const wrapper = this.canvas.parentElement;
    const rect = wrapper.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    
    this.canvas.width = rect.width * dpr;
    this.canvas.height = rect.height * dpr;
    this.ctx.scale(dpr, dpr);
    
    this.width = rect.width;
    this.height = rect.height;
    this.draw();
  }

  initEvents() {
    window.addEventListener('resize', () => this.resizeCanvas());

    // Mouse wheel zoom
    this.canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY < 0 ? 0.85 : 1.15;
      
      const xRange = (this.xMax - this.xMin) * zoomFactor;
      const yRange = (this.yMax - this.yMin) * zoomFactor;

      const xCenter = (this.xMin + this.xMax) / 2;
      const yCenter = (this.yMin + this.yMax) / 2;

      this.xMin = xCenter - xRange / 2;
      this.xMax = xCenter + xRange / 2;
      this.yMin = yCenter - yRange / 2;
      this.yMax = yCenter + yRange / 2;

      this.updateBoundsUI();
      this.draw();
    });

    // Mouse drag pan
    this.canvas.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.dragStartX = e.clientX;
      this.dragStartY = e.clientY;
    });

    window.addEventListener('mousemove', (e) => {
      if (this.isDragging) {
        const dx = e.clientX - this.dragStartX;
        const dy = e.clientY - this.dragStartY;
        this.dragStartX = e.clientX;
        this.dragStartY = e.clientY;

        const xUnitsPerPx = (this.xMax - this.xMin) / this.width;
        const yUnitsPerPx = (this.yMax - this.yMin) / this.height;

        this.xMin -= dx * xUnitsPerPx;
        this.xMax -= dx * xUnitsPerPx;
        this.yMin += dy * yUnitsPerPx;
        this.yMax += dy * yUnitsPerPx;

        this.updateBoundsUI();
        this.draw();
      } else {
        // Trace coordinates on hover
        const rect = this.canvas.getBoundingClientRect();
        const px = e.clientX - rect.left;
        if (px >= 0 && px <= this.width) {
          const mathX = this.pxToX(px);
          this.traceX = mathX;
          this.traceY1 = this.evaluateFunction(this.func1Str, mathX);
          this.traceY2 = this.evaluateFunction(this.func2Str, mathX);

          // Trigger UI update callback
          if (this.onTraceUpdate) {
            this.onTraceUpdate(this.traceX, this.traceY1, this.traceY2);
          }
          this.draw();
        }
      }
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });
  }

  updateBoundsUI() {
    const elXMin = document.getElementById('xMin');
    const elXMax = document.getElementById('xMax');
    const elYMin = document.getElementById('yMin');
    const elYMax = document.getElementById('yMax');
    if (elXMin) elXMin.value = this.xMin.toFixed(1);
    if (elXMax) elXMax.value = this.xMax.toFixed(1);
    if (elYMin) elYMin.value = this.yMin.toFixed(1);
    if (elYMax) elYMax.value = this.yMax.toFixed(1);
  }

  setFunctions(f1, color1, f2, color2) {
    this.func1Str = f1;
    this.color1 = color1;
    this.func2Str = f2;
    this.color2 = color2;
    this.draw();
  }

  setBounds(xMin, xMax, yMin, yMax) {
    this.xMin = parseFloat(xMin) || -10;
    this.xMax = parseFloat(xMax) || 10;
    this.yMin = parseFloat(yMin) || -10;
    this.yMax = parseFloat(yMax) || 10;
    this.draw();
  }

  // Coordinate Conversion Helpers
  xToPx(x) {
    return ((x - this.xMin) / (this.xMax - this.xMin)) * this.width;
  }

  yToPx(y) {
    return this.height - ((y - this.yMin) / (this.yMax - this.yMin)) * this.height;
  }

  pxToX(px) {
    return this.xMin + (px / this.width) * (this.xMax - this.xMin);
  }

  pxToY(py) {
    return this.yMin + ((this.height - py) / this.height) * (this.yMax - this.yMin);
  }

  // Safe Function Evaluator for math expressions in variable x
  evaluateFunction(expr, xVal) {
    if (!expr || expr.trim() === '') return null;
    try {
      let formatted = expr.replace(/\^/g, '**')
                          .replace(/sin/g, 'Math.sin')
                          .replace(/cos/g, 'Math.cos')
                          .replace(/tan/g, 'Math.tan')
                          .replace(/sqrt/g, 'Math.sqrt')
                          .replace(/abs/g, 'Math.abs')
                          .replace(/log/g, 'Math.log10')
                          .replace(/ln/g, 'Math.log')
                          .replace(/pi/g, 'Math.PI')
                          .replace(/e/g, 'Math.E');

      // Replace variable x cleanly (handling implicit multiplication like 2x -> 2*x)
      formatted = formatted.replace(/(\d+)\s*x/g, '$1*x');
      formatted = formatted.replace(/x/g, `(${xVal})`);

      const res = Function(`"use strict"; return (${formatted})`)();
      if (typeof res === 'number' && !isNaN(res) && isFinite(res)) {
        return res;
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  draw() {
    this.ctx.clearRect(0, 0, this.width, this.height);

    // Draw Grid & Axes
    this.drawGrid();
    this.drawAxes();

    // Plot Functions
    if (this.func1Str) this.plotCurve(this.func1Str, this.color1);
    if (this.func2Str) this.plotCurve(this.func2Str, this.color2);

    // Draw Crosshair / Trace indicator
    this.drawTracePoint();
  }

  drawGrid() {
    this.ctx.strokeStyle = "rgba(255, 255, 255, 0.06)";
    this.ctx.lineWidth = 1;
    this.ctx.fillStyle = "rgba(255, 255, 255, 0.3)";
    this.ctx.font = "10px Fira Code";

    // Step calculation
    const xStep = Math.pow(10, Math.floor(Math.log10((this.xMax - this.xMin) / 5)));
    const yStep = Math.pow(10, Math.floor(Math.log10((this.yMax - this.yMin) / 5)));

    // Vertical grid lines
    const startX = Math.ceil(this.xMin / xStep) * xStep;
    for (let x = startX; x <= this.xMax; x += xStep) {
      const px = this.xToPx(x);
      this.ctx.beginPath();
      this.ctx.moveTo(px, 0);
      this.ctx.lineTo(px, this.height);
      this.ctx.stroke();

      // Tick label
      if (Math.abs(x) > 0.0001) {
        const py = Math.min(Math.max(this.yToPx(0) + 12, 12), this.height - 5);
        this.ctx.fillText(x.toFixed(xStep < 1 ? 2 : 0), px + 2, py);
      }
    }

    // Horizontal grid lines
    const startY = Math.ceil(this.yMin / yStep) * yStep;
    for (let y = startY; y <= this.yMax; y += yStep) {
      const py = this.yToPx(y);
      this.ctx.beginPath();
      this.ctx.moveTo(0, py);
      this.ctx.lineTo(this.width, py);
      this.ctx.stroke();

      if (Math.abs(y) > 0.0001) {
        const px = Math.min(Math.max(this.xToPx(0) + 4, 4), this.width - 25);
        this.ctx.fillText(y.toFixed(yStep < 1 ? 2 : 0), px, py - 3);
      }
    }
  }

  drawAxes() {
    this.ctx.strokeStyle = "rgba(255, 255, 255, 0.4)";
    this.ctx.lineWidth = 1.5;

    // X axis
    const y0 = this.yToPx(0);
    this.ctx.beginPath();
    this.ctx.moveTo(0, y0);
    this.ctx.lineTo(this.width, y0);
    this.ctx.stroke();

    // Y axis
    const x0 = this.xToPx(0);
    this.ctx.beginPath();
    this.ctx.moveTo(x0, 0);
    this.ctx.lineTo(x0, this.height);
    this.ctx.stroke();
  }

  plotCurve(expr, color) {
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = 2.5;
    this.ctx.beginPath();

    let isDrawing = false;
    const stepPx = 1.5; // High precision sampling step

    for (let px = 0; px <= this.width; px += stepPx) {
      const mathX = this.pxToX(px);
      const mathY = this.evaluateFunction(expr, mathX);

      if (mathY !== null && !isNaN(mathY) && Math.abs(mathY) < 1e5) {
        const py = this.yToPx(mathY);
        if (!isDrawing) {
          this.ctx.moveTo(px, py);
          isDrawing = true;
        } else {
          // Discontinuity check for asymptotes like tan(x) or 1/x
          const prevPy = this.lastPy || py;
          if (Math.abs(py - prevPy) > this.height * 0.8) {
            this.ctx.stroke();
            this.ctx.beginPath();
            this.ctx.moveTo(px, py);
          } else {
            this.ctx.lineTo(px, py);
          }
        }
        this.lastPy = py;
      } else {
        if (isDrawing) {
          this.ctx.stroke();
          this.ctx.beginPath();
          isDrawing = false;
        }
      }
    }
    if (isDrawing) this.ctx.stroke();
  }

  drawTracePoint() {
    if (this.traceX === undefined) return;

    const px = this.xToPx(this.traceX);

    // Draw vertical dotted line
    this.ctx.strokeStyle = "rgba(255, 255, 255, 0.25)";
    this.ctx.setLineDash([4, 4]);
    this.ctx.beginPath();
    this.ctx.moveTo(px, 0);
    this.ctx.lineTo(px, this.height);
    this.ctx.stroke();
    this.ctx.setLineDash([]);

    // Draw dot for f1
    if (this.traceY1 !== null) {
      const py1 = this.yToPx(this.traceY1);
      if (py1 >= 0 && py1 <= this.height) {
        this.ctx.fillStyle = this.color1;
        this.ctx.beginPath();
        this.ctx.arc(px, py1, 5, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.strokeStyle = "#fff";
        this.ctx.lineWidth = 1.5;
        this.ctx.stroke();
      }
    }

    // Draw dot for f2
    if (this.traceY2 !== null) {
      const py2 = this.yToPx(this.traceY2);
      if (py2 >= 0 && py2 <= this.height) {
        this.ctx.fillStyle = this.color2;
        this.ctx.beginPath();
        this.ctx.arc(px, py2, 5, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.strokeStyle = "#fff";
        this.ctx.lineWidth = 1.5;
        this.ctx.stroke();
      }
    }
  }
}
